﻿
 clear host
 $server='PACHECO\SQL2017'


 
$username = 'sa_demo'
$password = 'ilovesql!'
$server = 'PACHECO\SQL2017'
$passwordX = $password | ConvertTo-SecureString -asPlainText -Force     
$Credentials = New-Object system.management.automation.pscredential -arg $username, $passwordX

 Invoke-DbaDiagnosticQuery -SqlInstance $server  -SqlCredential $Credentials -UseSelectionHelper  | Select -ExpandProperty result | ConvertTo-DbaDataTable #Format-Table -AutoSize


 #-------------------------------------------------

 
 #Invoke-DbaDiagnosticQuery -SqlInstance $server  -QueryName "Version Info" | Select -ExpandProperty result | ConvertTo-DbaDataTable #Format-Table -AutoSize

 
 #Invoke-DbaDiagnosticQuery -SqlInstance $server  -QueryName "Server Properties" | Select -ExpandProperty result | ConvertTo-DbaDataTable #Format-Table -AutoSize


 #Invoke-DbaDiagnosticQuery -SqlInstance $server  -QueryName "IO Warnings" | Select -ExpandProperty result | ConvertTo-DbaDataTable #Format-Table -AutoSize