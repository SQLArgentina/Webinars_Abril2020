clear-host
$username = 'sa_admin'
$password = 'Santi0612Salva2101'
$server = 'sql-mi-pass.public.4e9fc7286542.database.windows.net,3342'



$passwordX = $password | ConvertTo-SecureString -asPlainText -Force     
$Credentials = New-Object system.management.automation.pscredential -arg $username, $passwordX

Invoke-DbaDiagnosticQuery -SqlInstance $server -SqlCredential $Credentials -QueryName "Version Info"  | Select -ExpandProperty result | ConvertTo-DbaDataTable #Format-Table -AutoSize