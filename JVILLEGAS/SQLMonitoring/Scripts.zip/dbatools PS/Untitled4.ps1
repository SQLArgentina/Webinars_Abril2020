﻿#Disk Performance
clear host
$server = 'PACHECO'
(Test-DbaDiskSpeed -SqlInstance $server -sqlCredential $Credential | Select DiskLocation, FileName, ReadPerformance, WritePerformance)

#Test-DbaDiskSpeed