﻿#Export Instance to Scripts (DR purposes)
clear-host
$username = 'sa_demo'
$password = 'ilovesql!'
$server = 'PACHECO\SQL2017'

$passwordX = $password | ConvertTo-SecureString -asPlainText -Force     
$Credentials = New-Object system.management.automation.pscredential -arg $username, $passwordX

#Export-DbaInstance $server -SqlCredential $Credentials -Exclude Databases -Path C:\Temp\dbatools
Export-DbaInstance $server -Exclude Databases -Path C:\Temp\dbatools