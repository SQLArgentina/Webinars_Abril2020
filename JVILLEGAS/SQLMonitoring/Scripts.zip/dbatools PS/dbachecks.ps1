﻿#dbachecks

#Install-Module dbachecks -SkipPublisherCheck -Force
#Import-Module dbachecks -Force

#Install-Module Pester -SkipPublisherCheck -Force
#Import-Module Pester -Force

#Install-Module PSFramework -SkipPublisherCheck -Force
#Import-Module PSFramework -Force

#Invoke-Pester

#get-dbccheck

#Import-Module dbatools

$server="PACHECO"
 
Invoke-DbcCheck -SqlInstance $server -AllChecks


Invoke-DbcCheck -SqlInstance $server -ComputerName $server -AllChecks -Show Summary -PassThru | Update-DbcPowerBiDataSource
Start-DbcPowerBi
